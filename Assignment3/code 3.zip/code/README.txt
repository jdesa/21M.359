Jacqui De Sa

Pset #3

Collaboration Statement: I discussed the pset with CK, Kevin, and Emily (in class)


Part 1: MainWidget4
	Touch Mapping: The x axis of the screen is divided into 8 parts corresponding to intervals, and the y axis is divided up into parts corresponding to octaves. These two combined provide the note mapping for this part. Interval mapping is shown through the colors of the bubbles produces and octave mapping is shown via bubble opacity.

Part 2: MainWidget5
	Note playing scheme: Similar to in part one, the various portions of the bottom of the screen are divided up into parts corresponding to given intervals.  There is also a second note-playing scheme in which different bubbles are each generated in a random key and bounces change the relative interval they are at.

Part 3: 
	I included my ball collision module within part two.

Part 4: MainWidget6
	Flower petals light up when played and additional flowers can be added (each new flower is added in the next key of the circle of fifths)