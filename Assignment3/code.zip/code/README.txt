Jacqui De Sa

Pset #3

Collaboration Statement: I discussed the pset with CK, Kevin, and Emily (in class)


Part 1:
	Touch Mapping: The x axis of the screen is divided into 8 parts corresponding to intervals, and the y axis is divided up into parts corresponding to octaves. These two combined provide the note mapping for this part.

Part 2:
	Note playing scheme: Similar to in part one, the various portions of the bottom of the screen are divided up into parts corresponding to given intervals. 

Part 3:
	I included my simple collision detection function as well as the code for my more physically accurate collision detection function (which I couldn't fully debug).

Part 4:
	Flower petals light up when played and additional flowers can be added (each new flower is added in the next key of the circle of fifths)